import { BookingForm } from "@/components/booking-form"

export default function Page() {
  return (
    <main>
      <BookingForm />
    </main>
  )
}
